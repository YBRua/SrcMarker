from .common import BaseStringifier


class JavaStringifier(BaseStringifier):
    pass
