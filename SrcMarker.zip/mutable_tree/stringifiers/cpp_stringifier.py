from .common import BaseStringifier


class CppStringifier(BaseStringifier):
    pass
